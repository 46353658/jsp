package com.arshad.jsp;

public class FunUtils {
	public static String makeItUpper(String data) {
		return data.toUpperCase();
	}
}
